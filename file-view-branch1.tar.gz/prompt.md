Perfect! Now there is one thing the current approach is very slow for large files, what we can do instead is split up the file view message into two, the first one "pre" tells the frontend to open the frontend just like now with filename and filesize just like now, however we then continue with a "content" with the content.

The content can then either be sent as a stream and the frontend then loads in the content when it comes, or we send multiple content 








Over how this server communicates with the frontend, is it possible to send a stream of data without blocking the websocket? or is it better to send multiple chunks of data to still allow the server/frontend to do other stuff 