class SciFiTerminal {
    constructor() {
        this.terminal = null;
        this.websocket = null;
        this.fitAddon = null;
        this.isConnected = false;
        this.hasPlayedFirstPrompt = false;
        this.startTime = Date.now();
        this.isGridView = false;
        
        // File viewer pagination state
        this.fileCache = new Map(); // Cache for file chunks
        this.currentFile = null;
        this.pageSize = 0;
        this.charsPerLine = 0;
        this.linesPerPage = 0;
        this.bytesPerLine = 16; // For hex mode
        
        this.initStartupSequence();
    }

    // Audio helper functions
    playSound(path) {
        try {
            const audio = new Audio(path);
            audio.volume = 0.3;
            audio.play().catch(() => {
                // Silently fail if audio file doesn't exist or can't play
            });
        } catch (error) {
            // Silently fail if audio file doesn't exist
        }
    }

    // Startup sequence
    initStartupSequence() {
        const enterBtn = document.getElementById('enter-btn');
        enterBtn.addEventListener('click', () => {
            this.playSound('sfx/launch.mp3');
            this.startAnimationSequence();
        });
    }

    async startAnimationSequence() {
        const startupScreen = document.getElementById('startup-screen');
        const mainInterface = document.getElementById('main-interface');
        
        // Hide startup screen
        startupScreen.style.display = 'none';
        
        // Show dot
        const dot = document.createElement('div');
        dot.className = 'startup-dot';
        document.body.appendChild(dot);
        
        await this.sleep(500);
        this.playSound('sfx/uianim.mp3');
        
        // Animate dot to line
        dot.style.transition = 'all 1s ease';
        dot.style.width = '200px';
        dot.style.height = '2px';
        dot.style.borderRadius = '0';
        
        await this.sleep(1000);
        this.playSound('sfx/uianim.mp3');
        
        // Animate line to square
        dot.style.width = '400px';
        dot.style.height = '300px';
        dot.style.background = 'transparent';
        dot.style.border = '2px solid #00ff41';
        dot.style.borderRadius = '8px';
        
        await this.sleep(1000);
        this.playSound('sfx/uianim.mp3');
        
        // Calculate terminal position and dimensions
        const terminalContainer = document.getElementById('terminal-container');
        const terminalRect = terminalContainer.getBoundingClientRect();
        
        // Scale UP square to match terminal dimensions (2/3 width, full height, top-left aligned)
        dot.style.transition = 'all 1.5s ease';
        dot.style.position = 'fixed';
        dot.style.width = `${terminalRect.width}px`;
        dot.style.height = `${terminalRect.height}px`;
        dot.style.left = `${terminalRect.left}px`;
        dot.style.top = `${terminalRect.top}px`;
        // The square will scale UP from 400x300 to terminal dimensions
        
        await this.sleep(1500);
        this.playSound('sfx/uianim.mp3');
        
        // Remove animation element and show main interface
        dot.remove();
        mainInterface.classList.remove('hidden');
        
        // Initialize terminal
        this.setupTerminal();
        this.connectWebSocket();
        this.setupEventListeners();
        
        // Animate in sidebar and file explorer
        await this.sleep(500);
        this.showInfoPanel();
        
        await this.sleep(300);
        this.showFileExplorer();
        
        // Start info updates
        this.startInfoUpdates();
        
        // Request initial file system contents
        this.requestFileSystemContents();
        
        // Request initial system information
        this.requestSystemInfo();
        
        // Setup file explorer controls
        this.setupFileExplorerControls();
    }

    async showInfoPanel() {
        const infoPanel = document.getElementById('info-panel');
        infoPanel.classList.remove('hidden');
        infoPanel.style.transform = 'translateX(100%)';
        infoPanel.style.transition = 'transform 0.8s ease';
        
        await this.sleep(50);
        infoPanel.style.transform = 'translateX(0)';
        
        // Animate in text content
        setTimeout(() => {
            const infoValues = infoPanel.querySelectorAll('.info-value');
            infoValues.forEach((value, index) => {
                setTimeout(() => {
                    value.classList.add('text-appear');
                    this.playSound('sfx/appear.mp3');
                }, index * 100);
            });
        }, 800);
    }

    async showFileExplorer() {
        const fileExplorer = document.getElementById('file-explorer');
        fileExplorer.classList.remove('hidden');
        fileExplorer.style.transform = 'translateY(100%)';
        fileExplorer.style.transition = 'transform 0.8s ease';
        
        await this.sleep(50);
        fileExplorer.style.transform = 'translateY(0)';
    }

    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    setupTerminal() {
        // Initialize xterm.js terminal with sci-fi theme
        this.terminal = new Terminal({
            cursorBlink: true,
            cursorStyle: 'block',
            fontSize: 14,
            fontFamily: '"Courier New", "Monaco", "Menlo", monospace',
            theme: {
                background: 'transparent',
                foreground: '#00ff41',
                cursor: '#00ff41',
                cursorAccent: '#000000',
                selection: 'rgba(0, 255, 65, 0.3)',
                black: '#000000',
                red: '#ff0040',
                green: '#00ff41',
                yellow: '#ffff00',
                blue: '#0080ff',
                magenta: '#ff00ff',
                cyan: '#00ffff',
                white: '#ffffff',
                brightBlack: '#404040',
                brightRed: '#ff4080',
                brightGreen: '#80ff80',
                brightYellow: '#ffff80',
                brightBlue: '#80c0ff',
                brightMagenta: '#ff80ff',
                brightCyan: '#80ffff',
                brightWhite: '#ffffff'
            },
            allowTransparency: true,
            convertEol: true,
            scrollback: 1000,
            tabStopWidth: 4
        });

        // Add fit addon for responsive terminal
        this.fitAddon = new FitAddon.FitAddon();
        this.terminal.loadAddon(this.fitAddon);

        // Add web links addon
        this.terminal.loadAddon(new WebLinksAddon.WebLinksAddon());

        // Open terminal in the container
        this.terminal.open(document.getElementById('terminal'));
        
        // Initial fit
        this.fitAddon.fit();
        
        // Show connecting message
        this.terminal.write('\r\n\x1b[1;32m> NEXUS TERMINAL INITIALIZING...\x1b[0m\r\n');
        this.terminal.write('\x1b[1;36m> ESTABLISHING SECURE CONNECTION...\x1b[0m\r\n');
    }

    connectWebSocket() {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const wsUrl = `${protocol}//${window.location.host}`;
        
        this.websocket = new WebSocket(wsUrl);

        this.websocket.onopen = () => {
            this.isConnected = true;
            this.updateConnectionStatus('ONLINE');
            console.log('WebSocket connection established');
            
            // Clear loading message and send terminal size
            this.terminal.clear();
            this.terminal.write('\x1b[1;32m> CONNECTION ESTABLISHED\x1b[0m\r\n');
            this.terminal.write('\x1b[1;36m> NEXUS TERMINAL READY\x1b[0m\r\n\r\n');
            this.sendTerminalSize();
        };

        this.websocket.onmessage = (event) => {
            try {
                // Try to parse as JSON for file system messages
                const parsed = JSON.parse(event.data);
                console.log('WebSocket message received:', parsed);
                
                if (parsed.type === 'file_system') {
                    console.log('Handling file system message:', parsed.action);
                    this.handleFileSystemMessage(parsed);
                    return;
                }
                if (parsed.type === 'system_info') {
                    console.log('Handling system info message');
                    this.handleSystemInfoMessage(parsed);
                    return;
                }
                
                // If we get here, it's JSON but not handled - log it
                console.log('Unhandled JSON message type:', parsed.type);
            } catch (e) {
                console.log('Error parsing JSON:', e);
                // Not JSON, treat as terminal output
                
                // Safely handle event.data - it might not be a string
                if (event.data && typeof event.data === 'string') {
                    console.log('Non-JSON message, treating as terminal output:', event.data.substring(0, 100));
                    this.terminal.write(event.data);
                    
                    // Play sound on first prompt
                    if (!this.hasPlayedFirstPrompt && (event.data.includes('$') || event.data.includes('>'))) {
                        this.hasPlayedFirstPrompt = true;
                        this.playSound('sfx/appear.mp3');
                    }
                } else {
                    console.log('Non-JSON message with non-string data:', typeof event.data, event.data);
                    // Try to convert to string if possible
                    const dataString = String(event.data || '');
                    if (dataString) {
                        this.terminal.write(dataString);
                    }
                }
            }
        };

        this.websocket.onclose = () => {
            this.isConnected = false;
            this.updateConnectionStatus('OFFLINE');
            console.log('WebSocket connection closed');
            
            // Show disconnection message
            this.terminal.write('\r\n\x1b[1;31m> CONNECTION TERMINATED\x1b[0m\r\n');
            this.terminal.write('\x1b[1;33m> REFRESH TO RECONNECT\x1b[0m\r\n');
        };

        this.websocket.onerror = (error) => {
            console.error('WebSocket error:', error);
            this.updateConnectionStatus('ERROR');
            this.terminal.write('\r\n\x1b[1;31m> CONNECTION ERROR\x1b[0m\r\n');
        };
    }

    setupEventListeners() {
        // Handle terminal input
        this.terminal.onData((data) => {
            if (this.isConnected && this.websocket.readyState === WebSocket.OPEN) {
                this.websocket.send(data);
                // Play key sound for each keystroke
                this.playSound('sfx/key.mp3');
            }
        });

        // Handle window resize
        window.addEventListener('resize', () => {
            this.fitAddon.fit();
            this.sendTerminalSize();
            
            // Recalculate page size for file viewer if open
            if (this.currentFile && !document.getElementById('file-viewer-popup').classList.contains('hidden')) {
                this.calculatePageSize();
                // Clear cache and reload current view
                this.clearFileCache();
                this.reloadCurrentFileView();
            }
        });

        // Handle terminal resize
        this.terminal.onResize((size) => {
            this.sendTerminalSize();
        });

        // Handle keyboard shortcuts
        document.addEventListener('keydown', (event) => {
            // Ctrl+L to clear terminal
            if (event.ctrlKey && event.key === 'l') {
                event.preventDefault();
                this.terminal.clear();
            }
            
            // Escape key to close file viewer popup
            if (event.key === 'Escape') {
                this.closeFileViewer();
            }
        });

        // Setup file viewer popup close button
        const closeButton = document.getElementById('popup-close');
        if (closeButton) {
            closeButton.addEventListener('click', () => this.closeFileViewer());
        }

        // Setup click outside popup to clear highlights
        document.addEventListener('click', (event) => {
            const popup = document.getElementById('file-viewer-popup');
            if (popup && !popup.contains(event.target) && !popup.classList.contains('hidden')) {
                this.clearAllHighlights();
            }
        });
    }

    sendTerminalSize() {
        if (this.isConnected && this.websocket.readyState === WebSocket.OPEN) {
            const size = {
                type: 'resize',
                cols: this.terminal.cols,
                rows: this.terminal.rows
            };
            
            try {
                this.websocket.send(JSON.stringify(size));
            } catch (error) {
                console.warn('Failed to send terminal size:', error);
            }
        }
    }

    updateConnectionStatus(status) {
        const statusElement = document.getElementById('connection-status');
        statusElement.textContent = status;
        
        // Update status styling based on connection
        if (status === 'ONLINE') {
            statusElement.style.color = '#00ff41';
        } else if (status === 'OFFLINE') {
            statusElement.style.color = '#ff0040';
        } else {
            statusElement.style.color = '#ffff00';
        }
    }

    startInfoUpdates() {
        // Update frontend uptime every second
        setInterval(() => {
            const uptime = Date.now() - this.startTime;
            const hours = Math.floor(uptime / 3600000);
            const minutes = Math.floor((uptime % 3600000) / 60000);
            const seconds = Math.floor((uptime % 60000) / 1000);
            
            const uptimeElement = document.getElementById('uptime-info');
            if (uptimeElement) {
                uptimeElement.textContent = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            }
        }, 1000);

        // Update system info every 5 seconds
        setInterval(() => {
            this.requestSystemInfo();
        }, 5000);
    }

    requestFileSystemContents() {
        if (this.isConnected && this.websocket.readyState === WebSocket.OPEN) {
            this.websocket.send(JSON.stringify({
                type: 'file_system',
                action: 'get_contents'
            }));
            // Play sound effect for initial load
            this.playSound('sfx/appear.mp3');
        }
    }

    requestSystemInfo() {
        if (this.isConnected && this.websocket.readyState === WebSocket.OPEN) {
            this.websocket.send(JSON.stringify({
                type: 'system_info',
                action: 'get_info'
            }));
        }
    }

    handleFileSystemMessage(message) {
        if (message.type === 'file_system' && message.action === 'contents') {
            console.log('Received file system message with path:', message.path);
            this.populateFileExplorer(message.contents, message.path);
            // Update the path input field with current directory
            this.updatePathInput(message.path);
            // Play sound effect for directory change
            this.playSound('sfx/appear.mp3');
        } else if (message.type === 'file_system' && message.action === 'file_content') {
            console.log('Received file content:', message.filename, message.mode);
            this.showFileViewer(message.filename, message.mode, message.content, message.size);
        } else if (message.type === 'file_system' && message.action === 'file_chunk_response') {
            console.log('Received file chunk:', message.filename, 'offset:', message.offset, 'length:', message.length);
            this.handleFileChunkResponse(message);
        } else if (message.type === 'file_system' && message.action === 'error') {
            console.error('File system error:', message.message);
            // You could display this error to the user if needed
        }
    }

    handleSystemInfoMessage(message) {
        if (message.type === 'system_info' && message.action === 'info') {
            console.log('Received system info:', message.data);
            this.updateSystemInfo(message.data);
            // Play sound effect for info update
            this.playSound('sfx/appear.mp3');
        }
    }

    updateSystemInfo(data) {
        if (data.error) {
            console.error('System info error:', data.error);
            return;
        }

        // Update all system info fields
        this.updateInfoField('nexus-version', `${data.nexusVersion} (${data.nexusBranch})`);
        this.updateInfoField('node-version', data.nodeVersion);
        this.updateInfoField('host-os', data.hostOS);
        this.updateInfoField('host-platform', data.hostPlatform);
        this.updateInfoField('hostname', data.hostname);
        this.updateInfoField('cpu-model', data.cpuModel);
        this.updateInfoField('cpu-cores', data.cpuCores);
        this.updateInfoField('gpu-model', data.gpuModel);
        this.updateInfoField('current-user', data.currentUser);
        this.updateInfoField('process-count', data.processCount);
        this.updateInfoField('memory-usage', `${data.memoryUsed}GB / ${data.memoryTotal}GB (${data.memoryUsage}%)`);
        this.updateInfoField('storage-usage', `${data.storageUsed}MB / ${data.storageTotal}MB (${data.storageUsage}%)`);
        this.updateInfoField('cpu-usage', `${data.cpuUsage}%`);

        // Update server uptime
        const serverUptime = data.serverUptime;
        const hours = Math.floor(serverUptime / 3600);
        const minutes = Math.floor((serverUptime % 3600) / 60);
        const seconds = Math.floor(serverUptime % 60);
        this.updateInfoField('server-uptime', `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`);
    }

    updateInfoField(id, value) {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = value;
        }
    }

    openFile(filename) {
        if (this.isConnected && this.websocket.readyState === WebSocket.OPEN) {
            console.log('Opening file:', filename);
            this.websocket.send(JSON.stringify({
                type: 'file_system',
                action: 'get_file_content',
                filename: filename
            }));
        }
    }

    showFileViewer(filename, mode, content, size) {
        const popup = document.getElementById('file-viewer-popup');
        const filenameElement = document.getElementById('popup-filename');
        const textContent = document.getElementById('text-content');
        const binaryContent = document.getElementById('binary-content');
        const loadingIndicator = document.getElementById('loading-indicator');
        const textDisplay = document.getElementById('text-display');
        const hexData = document.getElementById('hex-data');
        const asciiData = document.getElementById('ascii-data');

        // Update filename
        filenameElement.textContent = `${filename} (${this.formatFileSize(size)})`;

        // Calculate page size for pagination (ensure it's done first)
        this.calculatePageSize();
        
        // Set current file info
        this.currentFile = { filename, mode, size };
        
        // Show loading indicator initially
        loadingIndicator.classList.remove('hidden');
        textContent.classList.add('hidden');
        binaryContent.classList.add('hidden');

        // Small delay to ensure page size calculation is complete
        setTimeout(() => {
            if (mode === 'text') {
                // Show text content with pagination
                this.displayTextContentPaged(textDisplay, content, size);
                loadingIndicator.classList.add('hidden');
                textContent.classList.remove('hidden');
            } else if (mode === 'binary') {
                // Show binary content in hex viewer with pagination
                this.displayHexViewerPaged(hexData, asciiData, content, size);
                loadingIndicator.classList.add('hidden');
                binaryContent.classList.remove('hidden');
            }
        }, 10);

        // Show popup
        popup.classList.remove('hidden');
        
        // Play sound effect
        this.playSound('sfx/appear.mp3');
    }

    displayHexViewer(hexContent, hexElement, asciiElement) {
        // Clear previous content
        hexElement.innerHTML = '';
        asciiElement.innerHTML = '';
        
        // Split hex content into bytes
        const hexBytes = hexContent.split(' ');
        const bytesPerLine = this.hexBytesPerLine || 16; // Use calculated value or fallback
        
        // Create line-by-line structure for better alignment
        for (let lineIndex = 0; lineIndex < Math.ceil(hexBytes.length / bytesPerLine); lineIndex++) {
            const lineStart = lineIndex * bytesPerLine;
            const lineEnd = Math.min(lineStart + bytesPerLine, hexBytes.length);
            
            // Create hex line
            const hexLine = document.createElement('div');
            hexLine.className = 'hex-line';
            hexLine.style.display = 'flex';
            hexLine.style.flexWrap = 'wrap';
            
            // Create ASCII line
            const asciiLine = document.createElement('div');
            asciiLine.className = 'ascii-line';
            asciiLine.style.display = 'flex';
            asciiLine.style.flexWrap = 'wrap';
            
            // Process bytes in this line
            for (let i = lineStart; i < lineEnd; i++) {
                const hex = hexBytes[i];
                const byte = parseInt(hex, 16);
                
                // Create hex byte element
                const hexByte = document.createElement('span');
                hexByte.className = 'hex-byte';
                hexByte.textContent = hex;
                hexByte.dataset.byteIndex = i;
                hexByte.dataset.lineIndex = lineIndex;
                hexByte.dataset.positionInLine = i - lineStart;
                
                // Create ASCII character element
                const asciiChar = document.createElement('span');
                asciiChar.className = 'ascii-char';
                asciiChar.dataset.byteIndex = i;
                asciiChar.dataset.lineIndex = lineIndex;
                asciiChar.dataset.positionInLine = i - lineStart;
                
                // Set ASCII content
                if (byte >= 32 && byte <= 126) {
                    // Printable ASCII
                    asciiChar.textContent = String.fromCharCode(byte);
                } else if (byte === 9) {
                    // Tab
                    asciiChar.textContent = '\\t';
                } else if (byte === 10) {
                    // Newline
                    asciiChar.textContent = '\\n';
                } else if (byte === 13) {
                    // Carriage return
                    asciiChar.textContent = '\\r';
                } else {
                    // Non-printable
                    asciiChar.textContent = '.';
                }
                
                // Add click event for highlighting
                hexByte.addEventListener('click', () => this.highlightBytePair(i, lineIndex, i - lineStart));
                asciiChar.addEventListener('click', () => this.highlightBytePair(i, lineIndex, i - lineStart));
                
                // Add to lines
                hexLine.appendChild(hexByte);
                asciiLine.appendChild(asciiChar);
            }
            
            // Add lines to containers
            hexElement.appendChild(hexLine);
            asciiElement.appendChild(asciiLine);
        }
        
        // Store reference to elements for highlighting
        this.hexElement = hexElement;
        this.asciiElement = asciiElement;
    }

    highlightBytePair(byteIndex, lineIndex, positionInLine) {
        // Clear previous highlights
        this.clearAllHighlights();
        
        // Find the hex byte and ASCII char elements
        const hexByte = this.hexElement.querySelector(`[data-byte-index="${byteIndex}"]`);
        const asciiChar = this.asciiElement.querySelector(`[data-byte-index="${byteIndex}"]`);
        
        if (hexByte && asciiChar) {
            // Add selected class to both elements
            hexByte.classList.add('selected');
            asciiChar.classList.add('selected');
            
            // Create selection highlight box
            this.createSelectionHighlight(hexByte, asciiChar);
        }
    }

    clearAllHighlights() {
        // Remove selected class from all elements
        const selectedHex = this.hexElement.querySelectorAll('.hex-byte.selected');
        const selectedAscii = this.asciiElement.querySelectorAll('.ascii-char.selected');
        
        selectedHex.forEach(el => el.classList.remove('selected'));
        selectedAscii.forEach(el => el.classList.remove('selected'));
        
        // Remove any existing selection highlights
        const highlights = document.querySelectorAll('.selection-highlight');
        highlights.forEach(el => el.remove());
    }

    createSelectionHighlight(hexByte, asciiChar) {
        // Get positions of both elements
        const hexRect = hexByte.getBoundingClientRect();
        const asciiRect = asciiChar.getBoundingClientRect();
        const popupRect = document.getElementById('file-viewer-popup').getBoundingClientRect();
        
        // Create highlight element
        const highlight = document.createElement('div');
        highlight.className = 'selection-highlight';
        
        // Position highlight to cover both elements
        const left = Math.min(hexRect.left, asciiRect.left) - popupRect.left;
        const top = hexRect.top - popupRect.top;
        const width = (Math.max(hexRect.right, asciiRect.right) - popupRect.left) - left;
        const height = Math.max(hexRect.height, asciiChar.height);
        
        highlight.style.left = `${left}px`;
        highlight.style.top = `${top}px`;
        highlight.style.width = `${width}px`;
        highlight.style.height = `${height}px`;
        
        // Add to popup
        document.getElementById('file-viewer-popup').appendChild(highlight);
        
        // Auto-remove highlight after a delay
        setTimeout(() => {
            if (highlight.parentNode) {
                highlight.remove();
            }
        }, 2000);
    }

    displayTextContentPaged(textElement, content, totalSize) {
        // Clear previous content
        textElement.innerHTML = '';
        
        // For small files, display directly
        if (totalSize <= this.pageSize) {
            textElement.textContent = content;
            return;
        }
        
        // For large files, implement pagination
        this.displayTextChunk(textElement, content, 0, this.pageSize, totalSize);
        
        // Add scroll event listener for pagination
        const textContent = document.getElementById('text-content');
        textContent.addEventListener('scroll', this.handleTextScroll.bind(this, textElement, totalSize));
    }

    displayHexViewerPaged(hexElement, asciiElement, content, totalSize) {
        // Clear previous content
        hexElement.innerHTML = '';
        asciiElement.innerHTML = '';
        
        // For small files, display directly
        if (totalSize <= this.hexPageSize) {
            this.displayHexViewer(content, hexElement, asciiElement);
            return;
        }
        
        // For large files, implement pagination
        this.displayHexChunk(hexElement, asciiElement, content, 0, this.hexPageSize, totalSize);
        
        // Add scroll event listener for pagination
        const binaryContent = document.getElementById('binary-content');
        binaryContent.addEventListener('scroll', this.handleHexScroll.bind(this, hexElement, asciiElement, totalSize));
    }

    displayTextChunk(textElement, content, offset, length, totalSize) {
        const chunk = content.substring(offset, offset + length);
        const chunkElement = document.createElement('div');
        chunkElement.className = 'text-chunk';
        chunkElement.dataset.offset = offset;
        chunkElement.textContent = chunk;
        
        textElement.appendChild(chunkElement);
        
        // Cache this chunk
        const cacheKey = `text_${offset}_${length}`;
        this.fileCache.set(cacheKey, chunk);
    }

    displayHexChunk(hexElement, asciiElement, content, offset, length, totalSize) {
        // Parse hex content for this chunk
        const hexBytes = content.split(' ').slice(offset, offset + length);
        
        // Create line-by-line structure for this chunk
        for (let lineIndex = 0; lineIndex < Math.ceil(hexBytes.length / this.hexBytesPerLine); lineIndex++) {
            const lineStart = lineIndex * this.hexBytesPerLine;
            const lineEnd = Math.min(lineStart + this.hexBytesPerLine, hexBytes.length);
            
            // Create hex line
            const hexLine = document.createElement('div');
            hexLine.className = 'hex-line';
            hexLine.dataset.offset = offset + lineStart;
            
            // Create ASCII line
            const asciiLine = document.createElement('div');
            asciiLine.className = 'ascii-line';
            asciiLine.dataset.offset = offset + lineStart;
            
            // Process bytes in this line
            for (let i = lineStart; i < lineEnd; i++) {
                const hex = hexBytes[i];
                const byte = parseInt(hex, 16);
                
                // Create hex byte element
                const hexByte = document.createElement('span');
                hexByte.className = 'hex-byte';
                hexByte.textContent = hex;
                hexByte.dataset.byteIndex = offset + i;
                
                // Create ASCII character element
                const asciiChar = document.createElement('span');
                asciiChar.className = 'ascii-char';
                asciiChar.dataset.byteIndex = offset + i;
                
                // Set ASCII content
                if (byte >= 32 && byte <= 126) {
                    asciiChar.textContent = String.fromCharCode(byte);
                } else if (byte === 9) {
                    asciiChar.textContent = '\\t';
                } else if (byte === 10) {
                    asciiChar.textContent = '\\n';
                } else if (byte === 13) {
                    asciiChar.textContent = '\\r';
                } else {
                    asciiChar.textContent = '.';
                }
                
                // Add click event for highlighting
                hexByte.addEventListener('click', () => this.highlightBytePair(offset + i, lineIndex, i - lineStart));
                asciiChar.addEventListener('click', () => this.highlightBytePair(offset + i, lineIndex, i - lineStart));
                
                // Add to lines
                hexLine.appendChild(hexByte);
                asciiLine.appendChild(asciiChar);
            }
            
            // Add lines to containers
            hexElement.appendChild(hexLine);
            asciiElement.appendChild(asciiLine);
        }
        
        // Cache this chunk
        const cacheKey = `hex_${offset}_${length}`;
        this.fileCache.set(cacheKey, hexBytes.join(' '));
    }

    handleTextScroll(textElement, totalSize) {
        const textContent = document.getElementById('text-content');
        const scrollTop = textContent.scrollTop;
        const scrollHeight = textContent.scrollHeight;
        const clientHeight = textContent.clientHeight;
        
        // Check if we need to load more content
        if (scrollTop + clientHeight >= scrollHeight - 100) {
            // Near bottom, load next chunk
            const lastChunk = this.getLastTextChunk(textElement);
            if (lastChunk) {
                const nextOffset = parseInt(lastChunk.dataset.offset) + this.pageSize;
                if (nextOffset < totalSize) {
                    this.requestFileChunk(this.currentFile.filename, nextOffset, this.pageSize, 'text');
                }
            }
        }
        
        if (scrollTop <= 100) {
            // Near top, load previous chunk
            const firstChunk = this.getFirstTextChunk(textElement);
            if (firstChunk) {
                const prevOffset = Math.max(0, parseInt(firstChunk.dataset.offset) - this.pageSize);
                if (prevOffset >= 0 && prevOffset < parseInt(firstChunk.dataset.offset)) {
                    this.requestFileChunk(this.currentFile.filename, prevOffset, this.pageSize, 'text');
                }
            }
        }
    }

    handleHexScroll(hexElement, asciiElement, totalSize) {
        const binaryContent = document.getElementById('binary-content');
        const scrollTop = binaryContent.scrollTop;
        const scrollHeight = binaryContent.scrollHeight;
        const clientHeight = binaryContent.clientHeight;
        
        // Check if we need to load more content
        if (scrollTop + clientHeight >= scrollHeight - 100) {
            // Near bottom, load next chunk
            const lastChunk = this.getLastHexChunk(hexElement);
            if (lastChunk) {
                const nextOffset = parseInt(lastChunk.dataset.offset) + this.hexPageSize;
                if (nextOffset < totalSize) {
                    this.requestFileChunk(this.currentFile.filename, nextOffset, this.hexPageSize, 'binary');
                }
            }
        }
        
        if (scrollTop <= 100) {
            // Near top, load previous chunk
            const firstChunk = this.getFirstHexChunk(hexElement);
            if (firstChunk) {
                const prevOffset = Math.max(0, parseInt(firstChunk.dataset.offset) - this.hexPageSize);
                if (prevOffset >= 0 && prevOffset < parseInt(firstChunk.dataset.offset)) {
                    this.requestFileChunk(this.currentFile.filename, prevOffset, this.hexPageSize, 'binary');
                }
            }
        }
    }

    getLastTextChunk(textElement) {
        const chunks = textElement.querySelectorAll('.text-chunk');
        return chunks[chunks.length - 1];
    }

    getFirstTextChunk(textElement) {
        const chunks = textElement.querySelectorAll('.text-chunk');
        return chunks[0];
    }

    getLastHexChunk(hexElement) {
        const chunks = hexElement.querySelectorAll('.hex-line');
        return chunks[chunks.length - 1];
    }

    getFirstHexChunk(hexElement) {
        const chunks = hexElement.querySelectorAll('.hex-line');
        return chunks[0];
    }

    handleFileChunkResponse(message) {
        console.log('Handling file chunk response:', message);
        
        if (!this.currentFile || message.filename !== this.currentFile.filename) {
            console.warn('Received chunk for different file');
            return;
        }

        // Validate message content
        if (!message.content) {
            console.error('File chunk response missing content field:', message);
            return;
        }

        // Cache the chunk
        const cacheKey = `${message.mode}_${message.offset}_${message.length}`;
        this.fileCache.set(cacheKey, message.content);

        // Display the chunk based on mode
        if (message.mode === 'text') {
            const textDisplay = document.getElementById('text-display');
            this.displayTextChunk(textDisplay, message.content, message.offset, message.length, message.totalSize);
        } else if (message.mode === 'binary') {
            const hexData = document.getElementById('hex-data');
            const asciiData = document.getElementById('ascii-data');
            this.displayHexChunk(hexData, asciiData, message.content, message.offset, message.length, message.totalSize);
        }
    }

    reloadCurrentFileView() {
        if (!this.currentFile) return;
        
        // Request initial chunks for current file
        if (this.currentFile.mode === 'text') {
            this.requestFileChunk(this.currentFile.filename, 0, this.pageSize, 'text');
        } else {
            this.requestFileChunk(this.currentFile.filename, 0, this.hexPageSize, 'binary');
        }
    }

    formatFileSize(bytes) {
        if (bytes < 1024) return `${bytes} B`;
        if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
        if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
        return `${(bytes / (1024 * 1024 * 1024)).toFixed(1)} GB`;
    }

    closeFileViewer() {
        const popup = document.getElementById('file-viewer-popup');
        if (popup) {
            popup.classList.add('hidden');
            // Clear file cache when closing
            this.clearFileCache();
            // Play sound effect
            this.playSound('sfx/appear.mp3');
        }
    }

    calculatePageSize() {
        const popup = document.getElementById('file-viewer-popup');
        if (!popup) return;
        
        const viewportHeight = window.innerHeight;
        const viewportWidth = window.innerWidth;
        
        // Popup dimensions (80% of viewport)
        const popupHeight = viewportHeight * 0.8;
        const popupWidth = viewportWidth * 0.8;
        
        // Header height (46px as per spec)
        const headerHeight = 46;
        
        // Content dimensions
        const contentHeight = popupHeight - headerHeight;
        const contentWidth = popupWidth;
        
        // Character dimensions (approximate for monospace font)
        const charWidth = 8; // 8px per character for 12px monospace font
        const lineHeight = 18; // 18px per line
        
        // Calculate page size
        this.charsPerLine = Math.floor(contentWidth / charWidth);
        this.linesPerPage = Math.floor(contentHeight / lineHeight);
        this.pageSize = this.charsPerLine * this.linesPerPage;
        
        // For hex mode, each byte is 3 characters (e.g., "FF ")
        // So we need to calculate how many bytes fit in the available width
        const hexCharsPerLine = Math.floor(contentWidth / charWidth);
        const hexBytesPerLine = 16; // 3 chars per byte
        this.hexBytesPerLine = Math.max(1, hexBytesPerLine); // Ensure at least 1 byte per line
        this.hexPageSize = this.hexBytesPerLine * this.linesPerPage;
        
        console.log('Page size calculated:', {
            text: this.pageSize,
            hex: this.hexPageSize,
            charsPerLine: this.charsPerLine,
            linesPerPage: this.linesPerPage,
            hexBytesPerLine: this.hexBytesPerLine
        });
    }

    clearFileCache() {
        this.fileCache.clear();
        this.currentFile = null;
    }

    requestFileChunk(filename, offset, length, mode) {
        if (this.isConnected && this.websocket.readyState === WebSocket.OPEN) {
            console.log('Requesting file chunk:', filename, 'offset:', offset, 'length:', length, 'mode:', mode);
            this.websocket.send(JSON.stringify({
                type: 'file_system',
                action: 'get_file_chunk',
                filename: filename,
                offset: offset,
                length: length,
                mode: mode
            }));
        }
    }

    populateFileExplorer(contents = [], currentPath = '') {
        const explorerContent = document.getElementById('explorer-content');
        console.log('Populating file explorer with:', contents);
        
        // Clear existing content
        explorerContent.innerHTML = '';
        
        // Add ".." entry at the top if not at root
        if (currentPath && currentPath !== '/') {
            const parentItem = document.createElement('div');
            parentItem.className = 'folder-item parent-item';
            
            if (this.isGridView) {
                parentItem.innerHTML = `
                    <img src="assets/fxfolder.svg" alt="parent" class="folder-icon" onerror="this.style.display='none'">
                    <span class="file-name">..</span>
                `;
            } else {
                parentItem.innerHTML = `
                    <img src="assets/fxfolder.svg" alt="parent" class="folder-icon" onerror="this.style.display='none'">
                    <span class="file-name">..</span>
                `;
            }
            
            parentItem.addEventListener('click', () => this.changeDirectory('..'));
            parentItem.classList.add('text-appear');
            explorerContent.appendChild(parentItem);
            this.playSound('sfx/appear.mp3');
        }
        
        // Add file and folder items
        contents.forEach((item, index) => {
            setTimeout(() => {
                const itemElement = document.createElement('div');
                itemElement.className = item.type === 'folder' ? 'folder-item' : 'file-item';
                
                const iconSrc = item.type === 'folder' ? 'assets/fxfolder.svg' : 'assets/fxfile.svg';
                console.log(`Creating ${item.type} item with icon: ${iconSrc}`);
                
                // Create different HTML for list vs grid view
                if (this.isGridView) {
                    itemElement.innerHTML = `
                        <img src="${iconSrc}" alt="${item.type}" class="${item.type === 'folder' ? 'folder-icon' : 'file-icon'}" onerror="this.style.display='none'" onload="console.log('Icon loaded:', this.src)">
                        <span class="file-name">${item.name}</span>
                        ${item.type === 'file' ? `<span class="file-info">${item.size}KB</span>` : ''}
                    `;
                } else {
                    itemElement.innerHTML = `
                        <img src="${iconSrc}" alt="${item.type}" class="${item.type === 'folder' ? 'folder-icon' : 'file-icon'}" onerror="this.style.display='none'" onload="console.log('Icon loaded:', this.src)">
                        <span class="file-name">${item.name}</span>
                        <span class="file-info">${item.type === 'folder' ? '' : `${item.size}KB`}</span>
                    `;
                }
                
                // Add click handler for folders
                if (item.type === 'folder') {
                    itemElement.addEventListener('click', () => this.changeDirectory(item.name));
                } else {
                    // Add double-click handler for files
                    itemElement.addEventListener('dblclick', () => this.openFile(item.name));
                }
                
                itemElement.classList.add('text-appear');
                explorerContent.appendChild(itemElement);
                this.playSound('sfx/appear.mp3');
            }, index * 150);
        });
    }

    changeDirectory(path) {
        if (this.isConnected && this.websocket.readyState === WebSocket.OPEN) {
            console.log('Changing directory to:', path);
            this.websocket.send(JSON.stringify({
                type: 'file_system',
                action: 'change_directory',
                path: path
            }));
        }
    }

    setupFileExplorerControls() {
        const pathInput = document.getElementById('path-input');
        const viewToggle = document.getElementById('view-toggle');
        
        // Path input handler
        pathInput.addEventListener('keypress', (event) => {
            if (event.key === 'Enter') {
                const path = pathInput.value.trim();
                if (path) {
                    this.navigateToPath(path);
                    pathInput.value = '';
                }
            }
        });
        
        // View toggle handler
        viewToggle.addEventListener('click', () => {
            this.toggleView();
        });
    }

    navigateToPath(path) {
        if (this.isConnected && this.websocket.readyState === WebSocket.OPEN) {
            console.log('Navigating to path:', path);
            this.websocket.send(JSON.stringify({
                type: 'file_system',
                action: 'change_directory',
                path: path
            }));
        }
    }

    toggleView() {
        this.isGridView = !this.isGridView;
        const explorerContent = document.getElementById('explorer-content');
        
        if (this.isGridView) {
            explorerContent.classList.add('grid-view');
        } else {
            explorerContent.classList.remove('grid-view');
        }
        
        // Play sound effect
        this.playSound('sfx/appear.mp3');
        
        // Re-render current content with new view
        this.refreshCurrentView();
    }

    refreshCurrentView() {
        // Re-request current directory contents to refresh the view
        this.requestFileSystemContents();
    }

    updatePathInput(currentPath) {
        const pathInput = document.getElementById('path-input');
        if (pathInput) {
            // Set the current path in the input field
            // Ensure we preserve the tilde if it exists
            pathInput.value = currentPath || '';
            console.log('Updated path input to:', currentPath);
        }
    }

    // Public methods for external control
    focus() {
        this.terminal.focus();
    }

    clear() {
        this.terminal.clear();
    }

    write(data) {
        this.terminal.write(data);
    }
}

// Initialize terminal when page loads
document.addEventListener('DOMContentLoaded', () => {
    const sciFiTerminal = new SciFiTerminal();
    
    // Make terminal globally accessible for debugging
    window.sciFiTerminal = sciFiTerminal;
});

// Handle page visibility changes
document.addEventListener('visibilitychange', () => {
    if (!document.hidden && window.sciFiTerminal && window.sciFiTerminal.terminal) {
        window.sciFiTerminal.focus();
    }
});

// Handle fullscreen changes
document.addEventListener('fullscreenchange', () => {
    setTimeout(() => {
        if (window.sciFiTerminal && window.sciFiTerminal.fitAddon) {
            window.sciFiTerminal.fitAddon.fit();
            window.sciFiTerminal.sendTerminalSize();
        }
    }, 100);
});